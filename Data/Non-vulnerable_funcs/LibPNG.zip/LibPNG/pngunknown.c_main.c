int
main(void)
{
   fprintf(stderr,
      " test ignored: no support to find out about unknown chunks\n");
   /* So the test is skipped: */
   return 77;
}
int
main(void)
{
   fprintf(stderr,
      " test ignored: no support to modify unknown chunk handling\n");
   /* So the test is skipped: */
   return 77;
}
