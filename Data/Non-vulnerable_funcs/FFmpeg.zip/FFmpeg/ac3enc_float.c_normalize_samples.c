 */
static int normalize_samples(AC3EncodeContext *s)
{
    return 0;
}
