/* routine to store a character in a string ... used only by "tokenizer" */
void chstore(char *string,int max,char ch)
{
  char c;
  if(_p_tokpos>=0&&_p_tokpos<max-1)
    {
      if(_p_state==IN_QUOTE)
        c=ch;
      else
        switch(_p_flag&3)
          {
          case 1: 	    /* convert to upper */
            c=toupper((int) ch);
            break;
          case 2: 	    /* convert to lower */
            c=tolower((int) ch);
            break;
          default:	    /* use as is */
            c=ch;
            break;
          }
      string[_p_tokpos++]=c;
    }
  return;
}
