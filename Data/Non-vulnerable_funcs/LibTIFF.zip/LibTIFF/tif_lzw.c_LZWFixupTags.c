static int
LZWFixupTags(TIFF* tif)
{
	(void) tif;
	return (1);
}
