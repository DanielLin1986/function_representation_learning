void
usage()
{
    error("usage: %s -[vq] [-|rasterfile] TIFFfile\n", NULL);
}
