static void
ReadError(char* what)
{
	Fatal("Error while reading %s", what);
}
