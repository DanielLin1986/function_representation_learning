void
libport_dummy_function()
{
        return;
}
