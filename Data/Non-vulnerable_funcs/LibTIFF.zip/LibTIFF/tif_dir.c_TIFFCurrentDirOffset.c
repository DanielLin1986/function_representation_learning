uint32
TIFFCurrentDirOffset(TIFF* tif)
{
	return (tif->tif_diroff);
}
