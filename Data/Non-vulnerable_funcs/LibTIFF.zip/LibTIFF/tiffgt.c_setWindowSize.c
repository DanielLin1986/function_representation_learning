static void
setWindowSize(void)
{
        glutReshapeWindow(width, height);
}
