*/
int mfs_size (int fd)
{
    int ret;
    if (fds[fd] == -1)  /* Not open */
    {
        ret = -1;
        errno = EBADF;
    }
    else
        ret = buf_size[fd];
    return (ret);
}
