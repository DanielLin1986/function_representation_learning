static void
raster_keys(unsigned char key, int x, int y)
{
        switch (key) {
                case 'b':                       /* photometric MinIsBlack */
                    photo = PHOTOMETRIC_MINISBLACK;
                    initImage();
                    break;
                case 'l':                       /* lsb-to-msb FillOrder */
                    order = FILLORDER_LSB2MSB;
                    initImage();
                    break;
                case 'm':                       /* msb-to-lsb FillOrder */
                    order = FILLORDER_MSB2LSB;
                    initImage();
                    break;
                case 'w':                       /* photometric MinIsWhite */
                    photo = PHOTOMETRIC_MINISWHITE;
                    initImage();
                    break;
                case 'W':                       /* toggle warnings */
                    owarning = TIFFSetWarningHandler(owarning);
                    initImage();
                    break;
                case 'E':                       /* toggle errors */
                    oerror = TIFFSetErrorHandler(oerror);
                    initImage();
                    break;
                case 'z':                       /* reset to defaults */
                case 'Z':
                    order = order0;
                    photo = photo0;
                    if (owarning == NULL)
                        owarning = TIFFSetWarningHandler(NULL);
                    if (oerror == NULL)
                        oerror = TIFFSetErrorHandler(NULL);
                    initImage();
                    break;
                case 'q':                       /* exit */
                case '\033':
                    cleanup_and_exit();
        }
        glutPostRedisplay();
}
