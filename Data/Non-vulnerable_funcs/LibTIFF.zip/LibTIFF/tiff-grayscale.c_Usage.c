void
Usage()
{
    fprintf(stderr, "Usage: %s -depth (8 | 4 | 2) tiff-image\n", programName);
    exit(0);
}
