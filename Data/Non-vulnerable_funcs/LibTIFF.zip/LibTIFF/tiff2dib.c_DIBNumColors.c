}
WORD DIBNumColors(LPSTR lpDIB)
{
   WORD wBitCount;  // DIB bit count
   /*  If this is a Windows-style DIB, the number of colors in the
    *  color table can be less than the number of bits per pixel
    *  allows for (i.e. lpbi->biClrUsed can be set to some value).
    *  If this is the case, return the appropriate value.
    */
   if (IS_WIN30_DIB(lpDIB))
   {
      DWORD dwClrUsed;
      dwClrUsed = ((LPBITMAPINFOHEADER)lpDIB)->biClrUsed;
      if (dwClrUsed)
     return (WORD)dwClrUsed;
   }
   /*  Calculate the number of colors in the color table based on
    *  the number of bits per pixel for the DIB.
    */
   if (IS_WIN30_DIB(lpDIB))
      wBitCount = ((LPBITMAPINFOHEADER)lpDIB)->biBitCount;
   else
      wBitCount = ((LPBITMAPCOREHEADER)lpDIB)->bcBitCount;
   /* return number of colors based on bits per pixel */
   switch (wBitCount)
      {
   case 1:
      return 2;
   case 4:
      return 16;
   case 8:
      return 256;
   default:
      return 0;
      }
}
