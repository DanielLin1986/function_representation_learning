}
TIFFImageIterEnd(TIFFImageIter* img)
{
    /* Nothing to free... ? */
}
