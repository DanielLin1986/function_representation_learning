void
_TIFFfree(tdata_t p)
{
	DisposePtr(p);
}
