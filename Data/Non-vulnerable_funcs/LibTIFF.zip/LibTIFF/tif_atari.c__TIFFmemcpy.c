void
_TIFFmemcpy(tdata_t d, const tdata_t s, size_t c)
{
	memcpy(d, s, (size_t) c);
}
