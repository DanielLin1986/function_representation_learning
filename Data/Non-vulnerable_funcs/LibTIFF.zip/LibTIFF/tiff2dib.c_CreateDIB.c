 ************************************************************************/
HDIB CreateDIB(DWORD dwWidth, DWORD dwHeight, WORD wBitCount)
{
   BITMAPINFOHEADER bi;         // bitmap header
   LPBITMAPINFOHEADER lpbi;     // pointer to BITMAPINFOHEADER
   DWORD dwLen;                 // size of memory block
   HDIB hDIB;
   DWORD dwBytesPerLine;        // Number of bytes per scanline
   // Make sure bits per pixel is valid
   if (wBitCount <= 1)
      wBitCount = 1;
   else if (wBitCount <= 4)
      wBitCount = 4;
   else if (wBitCount <= 8)
      wBitCount = 8;
   else if (wBitCount <= 24)
      wBitCount = 24;
   else
      wBitCount = 4;  // set default value to 4 if parameter is bogus
   // initialize BITMAPINFOHEADER
   bi.biSize = sizeof(BITMAPINFOHEADER);
   bi.biWidth = dwWidth;         // fill in width from parameter
   bi.biHeight = dwHeight;       // fill in height from parameter
   bi.biPlanes = 1;              // must be 1
   bi.biBitCount = wBitCount;    // from parameter
   bi.biCompression = BI_RGB;    
   bi.biSizeImage = (dwWidth*dwHeight*wBitCount)/8; //0;           // 0's here
mean "default"
   bi.biXPelsPerMeter = 2834; //0;
   bi.biYPelsPerMeter = 2834; //0;
   bi.biClrUsed = 0;
   bi.biClrImportant = 0;
   // calculate size of memory block required to store the DIB.  This
   // block should be big enough to hold the BITMAPINFOHEADER, the color
   // table, and the bits
   dwBytesPerLine =   (((wBitCount * dwWidth) + 31) / 32 * 4);
   dwLen = bi.biSize + PaletteSize((LPSTR)&bi) + (dwBytesPerLine * dwHeight);
   // alloc memory block to store our bitmap
   hDIB = GlobalAlloc(GHND, dwLen);
   // major bummer if we couldn't get memory block
   if (!hDIB)
   {
      return NULL;
   }
   // lock memory and get pointer to it
   lpbi = (VOID FAR *)GlobalLock(hDIB);
   // use our bitmap info structure to fill in first part of
   // our DIB with the BITMAPINFOHEADER
   *lpbi = bi;
   // Since we don't know what the colortable and bits should contain,
   // just leave these blank.  Unlock the DIB and return the HDIB.
   GlobalUnlock(hDIB);
   /* return handle to the DIB */
   return hDIB;
}
