 ************************************************************************/
HDIB LoadTIFFinDIB(LPSTR lpFileName)    
{
    TIFF          *tif;
    unsigned long imageLength; 
    unsigned long imageWidth; 
    unsigned int  BitsPerSample;
    unsigned long LineSize;
    unsigned int  SamplePerPixel;
    unsigned long RowsPerStrip;  
    int           PhotometricInterpretation;
    long          nrow;
	unsigned long row;
    char          *buf;          
    LPBITMAPINFOHEADER lpDIB; 
    HDIB          hDIB;
    char          *lpBits;
    HGLOBAL       hStrip;
    int           i,l;
    int           Align; 
    tif = TIFFOpen(lpFileName, "r");
    if (!tif)
        goto TiffOpenError;
    TIFFGetField(tif, TIFFTAG_IMAGEWIDTH, &imageWidth);
    TIFFGetField(tif, TIFFTAG_IMAGELENGTH, &imageLength);  
    TIFFGetField(tif, TIFFTAG_BITSPERSAMPLE, &BitsPerSample);
    TIFFGetField(tif, TIFFTAG_ROWSPERSTRIP, &RowsPerStrip);  
    TIFFGetField(tif, TIFFTAG_ROWSPERSTRIP, &RowsPerStrip);   
    TIFFGetField(tif, TIFFTAG_PHOTOMETRIC, &PhotometricInterpretation);
    LineSize = TIFFScanlineSize(tif); //Number of byte in ine line
    SamplePerPixel = (int) (LineSize/imageWidth);
    //Align = Number of byte to add at the end of each line of the DIB
    Align = 4 - (LineSize % 4);
    if (Align == 4)	Align = 0;
    //Create a new DIB
    hDIB = CreateDIB((DWORD) imageWidth, (DWORD) imageLength, (WORD)
(BitsPerSample*SamplePerPixel));
    lpDIB  = (LPBITMAPINFOHEADER) GlobalLock(hDIB);
    if (!lpDIB)
          goto OutOfDIBMemory;
    if (lpDIB)
       lpBits = FindDIBBits((LPSTR) lpDIB);
    //In the tiff file the lines are save from up to down 
	//In a DIB the lines must be save from down to up
    if (lpBits)
      {
        lpBits = FindDIBBits((LPSTR) lpDIB);
        lpBits+=((imageWidth*SamplePerPixel)+Align)*(imageLength-1);
		//now lpBits pointe on the bottom line
        hStrip = GlobalAlloc(GHND,TIFFStripSize(tif));
        buf = GlobalLock(hStrip);           
        if (!buf)
           goto OutOfBufMemory;
        //PhotometricInterpretation = 2 image is RGB
        //PhotometricInterpretation = 3 image have a color palette              
        if (PhotometricInterpretation == 3)
        {
          uint16* red;
          uint16* green;
          uint16* blue;
          int16 i;
          LPBITMAPINFO lpbmi;   
          int   Palette16Bits;          
          TIFFGetField(tif, TIFFTAG_COLORMAP, &red, &green, &blue); 
		  //Is the palette 16 or 8 bits ?
          if (checkcmap(1<<BitsPerSample, red, green, blue) == 16) 
             Palette16Bits = TRUE;
          else
             Palette16Bits = FALSE;
          lpbmi = (LPBITMAPINFO)lpDIB;                      
          //load the palette in the DIB
          for (i = (1<<BitsPerSample)-1; i >= 0; i--) 
            {             
             if (Palette16Bits)
                {
                  lpbmi->bmiColors[i].rgbRed =(BYTE) CVT(red[i]);
                  lpbmi->bmiColors[i].rgbGreen = (BYTE) CVT(green[i]);
                  lpbmi->bmiColors[i].rgbBlue = (BYTE) CVT(blue[i]);           
                }
             else
                {
                  lpbmi->bmiColors[i].rgbRed = (BYTE) red[i];
                  lpbmi->bmiColors[i].rgbGreen = (BYTE) green[i];
                  lpbmi->bmiColors[i].rgbBlue = (BYTE) blue[i];        
                }
            }  
        }
        //read the tiff lines and save them in the DIB
		//with RGB mode, we have to change the order of the 3 samples RGB
<=> BGR
        for (row = 0; row < imageLength; row += RowsPerStrip) 
          {     
            nrow = (row + RowsPerStrip > imageLength ? imageLength - row :
RowsPerStrip);
            if (TIFFReadEncodedStrip(tif, TIFFComputeStrip(tif, row, 0),
                buf, nrow*LineSize)==-1)
                  {
                     goto TiffReadError;
                  } 
            else
                  {  
                    for (l = 0; l < nrow; l++) 
                      {
                         if (SamplePerPixel  == 3)
                           for (i=0;i< (int) (imageWidth);i++)
                              {
                               lpBits[i*SamplePerPixel+0]=buf[l*LineSize+i*Sample
PerPixel+2]; 
                               lpBits[i*SamplePerPixel+1]=buf[l*LineSize+i*Sample
PerPixel+1];
                               lpBits[i*SamplePerPixel+2]=buf[l*LineSize+i*Sample
PerPixel+0];
                              }
                         else
                           memcpy(lpBits, &buf[(int) (l*LineSize)], (int)
imageWidth*SamplePerPixel); 
                         lpBits-=imageWidth*SamplePerPixel+Align;
                      }
                 }
          }
        GlobalUnlock(hStrip);
        GlobalFree(hStrip);
        GlobalUnlock(hDIB); 
        TIFFClose(tif);
      }
    return hDIB;
    OutOfBufMemory:
    TiffReadError:
       GlobalUnlock(hDIB); 
       GlobalFree(hStrip);
    OutOfDIBMemory:
       TIFFClose(tif);
    TiffOpenError:
       return (HANDLE) 0;
}
