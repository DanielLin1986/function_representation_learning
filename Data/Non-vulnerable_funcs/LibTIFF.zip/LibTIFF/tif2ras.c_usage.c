void
usage()
{
    error("usage: %s -[vq] TIFFfile [rasterfile]\n", NULL);
}
