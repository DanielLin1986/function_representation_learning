static tmsize_t 
t2p_readproc(thandle_t handle, tdata_t data, tmsize_t size) 
{
	(void) handle, (void) data, (void) size;
	return -1;
}
