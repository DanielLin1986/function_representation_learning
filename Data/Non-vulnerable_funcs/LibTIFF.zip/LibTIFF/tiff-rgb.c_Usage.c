void
Usage()
{
    fprintf(stderr, "Usage: %s -gamma gamma tiff-image\n", programName);
    exit(0);
}
