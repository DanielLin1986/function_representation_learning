void
_TIFFmemset(tdata_t p, int v, size_t c)
{
	memset(p, v, (size_t) c);
}
