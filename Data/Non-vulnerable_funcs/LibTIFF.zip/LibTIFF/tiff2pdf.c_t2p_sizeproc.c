static uint64 
t2p_sizeproc(thandle_t handle) 
{
	(void) handle;
	return -1;
}
